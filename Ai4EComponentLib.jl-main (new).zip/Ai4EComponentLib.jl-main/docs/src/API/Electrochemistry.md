# ElectrochemistryAPI

```@meta
CurrentModule = Ai4EComponentLib.Electrochemistry
```

```@contents
Pages = ["Electrochemistry.md"]
```

## Index

```@index
Pages = ["Electrochemistry.md"]
```

## Electrochemistry Components

```@autodocs
Modules = [Electrochemistry]
```

